#!/bin/bash
Name=$1
/bin/su -s /bin/bash -c 'DISPLAY=:0 /usr/bin/notify-send -i         /usr/share/pixmaps/gnome-set-time.png "ALERT"         "You will be logged out in 5 minutes."' $Name
