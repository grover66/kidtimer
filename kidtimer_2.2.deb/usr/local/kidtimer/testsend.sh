#!/bin/bash
M=1
LINE=
DISPLAY=:0 /usr/bin/notify-send -i /usr/share/pixmaps/gnome-set-time.png "ALERT" "You will be logged out in 1 minute."
