#!/bin/bash
basedir="/usr/local/kidtimer"
configdir="/etc/kidtimer"
LINE=`sed -n '4p' $basedir/locale/$LANG`
DISPLAY=:0 /usr/bin/notify-send -i /usr/share/pixmaps/gnome-set-time.png "ALERT" "$LINE"
