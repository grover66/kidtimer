#!/bin/bash
basedir="/usr/local/kidtimer"
configdir="/etc/kidtimer"
[ ! -e $basedir/locale/$LANG ] && LANG="en_US.UTF-8" #defaults to english.
LINE=`sed -n '4p' $basedir/locale/$LANG`
DISPLAY=:0 /usr/bin/notify-send -i /usr/share/pixmaps/gnome-set-time.png "ALERT" "$LINE"
